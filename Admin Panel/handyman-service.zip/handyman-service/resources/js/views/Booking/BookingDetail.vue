<template>
</template>
<script>
export default {
    name:'BookingDetail'
}
</script>
