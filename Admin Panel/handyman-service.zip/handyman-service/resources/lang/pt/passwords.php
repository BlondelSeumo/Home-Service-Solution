<?php 
return [
  'reset' => 'Sua senha foi alterada!',
  'sent' => 'Nós enviamos o seu link de redefinição de senha!',
  'throttled' => 'Por favor, aguarde antes de tentar novamente.',
  'token' => 'Este token de redefinição de senha é inválido.',
  'user' => 'Não podemos encontrar um usuário com esse endereço de e-mail.',
];