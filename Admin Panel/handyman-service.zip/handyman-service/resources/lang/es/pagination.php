<?php 
return [
  'previous' => 'Previa',
  'next' => 'Siguiente',
];