<?php 
return [
  'previous' => 'precedente',
  'next' => 'prossima',
];